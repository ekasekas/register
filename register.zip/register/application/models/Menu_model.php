<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Menu_model extends CI_Model {

    public function getSubMenu(){
        $query = "SELECT `user_sub_menu`.*, `user_menu`.`menu`
                    FROM `user_sub_menu` JOIN `user_menu`
                    ON `user_sub_menu`.`menu_id` = `user_menu`.`id`
                ";
        return $this->db->query($query)->result_array();
    }

    public function getJenisKelamin($email){
        $query = "SELECT `user`.*, `jns_kelamin`.`jenis_kelamin`
                    FROM `user` JOIN `jns_kelamin`
                    ON `user`.`jenis_kelamin_id` = `jns_kelamin`.`id`
                    WHERE `user`.`email`='$email'
                ";
        return $this->db->query($query)->result_array();
    }

    public function getKewarganegaraan($email){
        $query = "SELECT `user`.*, `kenegaraan`.`kewarganegaraan`
                    FROM `user` JOIN `kenegaraan`
                    ON `user`.`kewarganegaraan_id` = `kenegaraan`.`id`
                    WHERE `user`.`email`='$email'
                ";
        return $this->db->query($query)->result_array();
    }

    public function getKawasan($email){
        $query = "SELECT `user`.*, `zona`.`kawasan`
                    FROM `user` JOIN `zona`
                    ON `user`.`kawasan_id` = `zona`.`id`
                    WHERE `user`.`email`='$email'
                ";
        return $this->db->query($query)->result_array();
    }

    public function getKlusterKeahlian($email){
        $query = "SELECT `user`.*, `keahlian`.`kluster_keahlian`
                    FROM `user` JOIN `keahlian`
                    ON `user`.`kluster_keahlian_id` = `keahlian`.`id`
                    WHERE `user`.`email`='$email'
                ";
        return $this->db->query($query)->result_array();
    }

    public function getStatusKeanggotaan($email){
        $query = "SELECT `user`.*, `keanggotaan`.`status_keanggotaan`
                    FROM `user` JOIN `keanggotaan`
                    ON `user`.`status_keanggotaan_id` = `keanggotaan`.`id`
                    WHERE `user`.`email`='$email'
                ";
        return $this->db->query($query)->result_array();
    }

    public function getTanggalUpdate($email){
        $query = "SELECT `tanggal_update` FROM `user` WHERE `user`.`email` = '$email'";
        return $this->db->query($query)->result_array();
    }

    public function getAll(){
        $admin_kawasan= $this->session->userdata('admin_kawasan');
        $this->db->select('*');
        $this->db->from('user');
        $this->db->join('jns_kelamin', 'user.jenis_kelamin_id=jns_kelamin.id');
        $this->db->join('zona', 'user.kawasan_id=zona.id');
        $this->db->join('keanggotaan', 'user.status_keanggotaan_id=keanggotaan.id');
        $this->db->join('keahlian', 'user.kluster_keahlian_id=keahlian.id');
        $this->db->join('kenegaraan', 'user.kewarganegaraan_id=kenegaraan.id');
        $this->db->where('kawasan',$admin_kawasan);
        $this->db->where('status_keanggotaan_id=2');
        return $this->db->get();
    }
    
    // hapus menu
    public function deleteMenu($id){
        $this->db->delete('user_menu', ['id' => $id]);
    }
    // hapus role
    public function deleteRole($id){
        $this->db->delete('user_role', ['id' => $id]);
    }
    // hapus submenu
    public function deleteSubmenu($id){
        $this->db->delete('user_sub_menu', ['id' => $id]);
    }

}
?>