<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Menu_model extends CI_Model {

    public function getSubMenu(){
        $query = "SELECT `user_sub_menu`.*, `user_menu`.`menu`
                    FROM `user_sub_menu` JOIN `user_menu`
                    ON `user_sub_menu`.`menu_id` = `user_menu`.`id`
                ";
        return $this->db->query($query)->result_array();
    }

    public function getJenisKelamin(){
        $query = "SELECT `user`.*, `jns_kelamin`.`jenis_kelamin`
                    FROM `user` JOIN `jns_kelamin`
                    ON `user`.`jenis_kelamin_id` = `jns_kelamin`.`id`
                ";
        return $this->db->query($query)->result_array();
    }

    public function getKewarganegaraan(){
        $query = "SELECT `user`.*, `kenegaraan`.`kewarganegaraan`
                    FROM `user` JOIN `kenegaraan`
                    ON `user`.`kewarganegaraan_id` = `kenegaraan`.`id`
                ";
        return $this->db->query($query)->result_array();
    }

    public function getKlusterKeahlian(){
        $query = "SELECT `user`.*, `keahlian`.`kluster_keahlian`
                    FROM `user` JOIN `keahlian`
                    ON `user`.`kluster_keahlian_id` = `keahlian`.`id`
                ";
        return $this->db->query($query)->result_array();
    }

    public function getStatusKeanggotaan(){
        $query = "SELECT `user`.*, `keanggotaan`.`status_keanggotaan`
                    FROM `user` JOIN `keanggotaan`
                    ON `user`.`status_keanggotaan_id` = `keanggotaan`.`id`
                ";
        return $this->db->query($query)->result_array();
    }
}