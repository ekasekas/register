

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

            <div class="row">
                <div class="col-lg">
                    <?= form_open_multipart('user/edit'); ?>
                        <div class="form-group">
                            <label for="nama">Nama</label>
                            <input type="text" class="form-control" id="nama" name="nama" placeholder="">
                            <?= form_error('nama', '<small class="text-danger pl=3">', '</small>');?>
                        </div>
                        <div class="form-group">
                            <label for="jenis_kelamin_id">Jenis Kelamin</label>
                            <select class="form-control" id="jenis_kelamin_id" name="jenis_kelamin_id">
                                <?php foreach ($jenis_kelamin as $j) : ?>
                                <option value="<?= $j['id']; ?>"><?= $j['jenis_kelamin']; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="kewarganegaraan_id">Kewarganegaraan</label>
                            <select class="form-control" id="kewarganegaraan_id" name="kewarganegaraan_id">
                                <?php foreach ($kewarganegaraan as $k) : ?>
                                <option value="<?= $k['id']; ?>"><?= $k['kewarganegaraan']; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="negara">Negara</label>
                            <input type="text" class="form-control" id="negara" name="negara" placeholder="">
                            <?= form_error('negara', '<small class="text-danger pl=3">', '</small>');?>
                        </div>
                        <div class="form-group">
                            <label for="kota">Kota</label>
                            <input type="text" class="form-control" id="kota" name="kota" placeholder="">
                            <?= form_error('kota', '<small class="text-danger pl=3">', '</small>');?>
                        </div>
                        <div class="form-group">
                            <label for="gelar">Gelar</label>
                            <input type="text" class="form-control" id="gelar" name="gelar" placeholder="">
                            <?= form_error('gelar', '<small class="text-danger pl=3">', '</small>');?>
                        </div>
                        <div class="form-group">
                            <label for="institusi">Institusi</label>
                            <input type="text" class="form-control" id="institusi" name="institusi" placeholder="">
                            <?= form_error('institusi', '<small class="text-danger pl=3">', '</small>');?>
                        </div>
                        <div class="form-group">
                            <label for="departemen">Departemen</label>
                            <input type="text" class="form-control" id="departemen" name="departemen" placeholder="">
                            <?= form_error('departemen', '<small class="text-danger pl=3">', '</small>');?>
                        </div>
                        <div class="form-group">
                            <label for="jabatan">Jabatan</label>
                            <input class="form-control" id="jabatan" name="jabatan" type="text" value="<?= $user['jabatan']; ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label for="kluster_keahlian_id">Kluster Keahlian</label>
                            <select class="form-control" id="kluster_keahlian_id" name="kluster_keahlian_id">
                                <?php foreach ($kluster_keahlian as $kh) : ?>
                                <option value="<?= $kh['id']; ?>"><?= $kh['kluster_keahlian']; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="email_resmi">Email Resmi</label>
                            <input type="text" class="form-control" id="email_resmi" name="email_resmi" placeholder="">
                            <?= form_error('email_resmi', '<small class="text-danger pl=3">', '</small>');?>
                        </div>
                        <div class="form-group">
                            <label for="email">Email Pribadi</label>
                            <input class="form-control" id="email" name="email" type="text" value="<?= $user['email']; ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label for="no_telp">Nomor Telepon</label>
                            <input type="text" class="form-control" id="no_telp" name="no_telp" placeholder="">
                            <?= form_error('no_telp', '<small class="text-danger pl=3">', '</small>');?>
                        </div>
                        <div class="form-group">
                            <label for="website">Website</label>
                            <input type="text" class="form-control" id="website" name="website" placeholder="">
                            <?= form_error('website', '<small class="text-danger pl=3">', '</small>');?>
                        </div>
                        <div class="form-group">
                            <label for="research_interest">Research Interest</label>
                            <input type="text" class="form-control" id="research_interest" name="research_interest" placeholder="">
                            <?= form_error('research_interest', '<small class="text-danger pl=3">', '</small>');?>
                        </div>
                        <div class="form-group">
                            <label for="research">Google Scholar / Scopus ID / RG / ORCHID / PUBLONS / LinkedIn</label>
                            <input type="text" class="form-control" id="research" name="research" placeholder="">
                            <?= form_error('research', '<small class="text-danger pl=3">', '</small>');?>
                        </div>
                        <div class="form-group">
                            <label for="status_keanggotaan_id">Status Keanggotaan</label>
                            <select class="form-control" id="status_keanggotaan_id" name="status_keanggotaan_id">
                                <?php foreach ($status_keanggotaan as $sk) : ?>
                                <option value="<?= $sk['id']; ?>"><?= $sk['status_keanggotaan']; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <!-- upload gambar -->
                        <!-- <div class="form-group">
                            <label for="research">Foto</label>
                            <div class="col-sm-12">
                                <div class="row">
                                    <div class="col-sm-2">
                                        <img src="<?= base_url('assets/img/') . $user['foto']; ?>" class="img-thumbnail">
                                    </div>
                                    <div class="col-sm-10">
                                        <div class="custom-file">
                                            <input type="file" class="custom-file-input" id="foto" name="foto">
                                        <label class="custom-file-label" for="foto">Choose your picture</label>
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div> -->
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </form>
                </div>
            </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->
