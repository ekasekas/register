
        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800"><?= $title; ?></h1>
          
          <div class="row">
            <div class="col-lg-6">
                <?= $this->session->flashdata('message'); ?>
            </div>
          </div>

          <div class="card mb-3">
            <div class="row no-gutters">
                <div class="col-md-2 ml-4 mt-4">
                    <img src="<?= base_url('assets/img/people.jpg'); ?>" style="max-width: 300px;" class="card-img" alt="...">
                </div>
                <div class="col-lg ml-4 mt-4">
                    <table class="table table-bordered">
                            <tr>
                                <th>1</th>
                                <th>Nama</th>
                                <td><?= $user['nama']; ?></td>
                            </tr>
                            <tr>
                                <th>2</th>
                                <th>Jenis Kelamin</th>
                                <?php foreach($jenisKelamin as $jk) : ?>
                                <td><?= $jk['jenis_kelamin']; ?></td>
                                <?php endforeach; ?>
                            </select>
                            </tr>
                            <tr>
                                <th>3</th>
                                <th>Kewarganegaraan</th>
                                <?php foreach($kewargaNegaraan as $kw) : ?>
                                <td><?= $kw['kewarganegaraan']; ?></td>
                                <?php endforeach; ?>
                            </tr>
                            <tr>
                                <th>4</th>
                                <th>Negara</th>
                                <td><?= $user['negara']; ?></td>
                            </tr>
                            <tr>
                                <th>5</th>
                                <th>Kota</th>
                                <td><?= $user['kota']; ?></td>
                            </tr>
                            <tr>
                                <th>6</th>
                                <th>Gelar</th>
                                <td><?= $user['gelar']; ?></td>
                            </tr>
                            <tr>
                                <th>7</th>
                                <th>Institusi</th>
                                <td><?= $user['institusi']; ?></td>
                            </tr>
                            <tr>
                                <th>8</th>
                                <th>Departemen</th>
                                <td><?= $user['departemen']; ?></td>
                            </tr>
                            <tr>
                                <th>9</th>
                                <th>Jabatan</th>
                                <td><?= $user['jabatan']; ?></td>
                            </tr>
                            <tr>
                                <th>10</th>
                                <th>Kluster Keahlian</th>
                                <?php foreach($klusterKeahlian as $kk) : ?>
                                <td><?= $kk['kluster_keahlian']; ?></td>
                                <?php endforeach; ?>
                            </tr>
                            <tr>
                                <th>11</th>
                                <th>Email Resmi</th>
                                <td><?= $user['email_resmi']; ?></td>
                            </tr>
                            <tr>
                                <th>12</th>
                                <th>Email</th>
                                <td><?= $user['email']; ?></td>
                            </tr>
                            <tr>
                                <th>13</th>
                                <th>Nomor Telepon</th>
                                <td><?= $user['no_telp']; ?></td>
                            </tr>
                            <tr>
                                <th>14</th>
                                <th>Website</th>
                                <td><?= $user['website']; ?></td>
                            </tr>
                            <tr>
                                <th>15</th>
                                <th>Research Interest</th>
                                <td><?= $user['research_interest']; ?></td>
                            </tr>
                            <tr>
                                <th>16</th>
                                <th>Google Scholar / Scopus ID / RG / ORCHID / PUBLONS / LinkedIn</th>
                                <td><?= $user['research']; ?></td>
                            </tr>
                            <tr>
                                <th>17</th>
                                <th>Status Keanggotaan</th>
                                <?php foreach($statusKeanggotaan as $sk) : ?>
                                <td><?= $sk['status_keanggotaan']; ?></td>
                                <?php endforeach; ?>
                            </tr>
                            <tr>
                                <th>18</th>
                                <th>Tanggal Update</th>
                                <td><?= $user['tanggal_update']; ?></td>
                            </tr>
                    </table>
                </div>
            </div>
        </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->
