<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

    public function __construct(){
        parent::__construct();
        is_logged_in();
    }

    public function index(){
        $data['title'] = 'My Profile';
        $data['user'] = $this->db->get_where('user', ['email' => 
        $this->session->userdata('email')])->row_array();
        
        $email= $this->session->userdata('email');
        // dropdown jenis kelamin
        $this->load->model('Menu_model', 'jenis_kelamin');
        $data['jenisKelamin'] = $this->jenis_kelamin->getJenisKelamin($email);
        $data['jenis_kelamin'] = $this->db->get('jns_kelamin')->result_array();

        // dropdown kewarganegaraan
        $this->load->model('Menu_model', 'kewarganegaraan');
        $data['kewargaNegaraan'] = $this->kewarganegaraan->getKewarganegaraan($email);
        $data['kewarganegaraan'] = $this->db->get('kenegaraan')->result_array();

        // dropdown kawasan/zona
        $this->load->model('Menu_model', 'kawasan');
        $data['zona'] = $this->kawasan->getKawasan($email);
        $data['kawasan'] = $this->db->get('zona')->result_array();

        // dropdown keahlian
        $this->load->model('Menu_model', 'kluster_keahlian');
        $data['klusterKeahlian'] = $this->kluster_keahlian->getKlusterKeahlian($email);
        $data['kluster_keahlian'] = $this->db->get('keahlian')->result_array();

        // dropdown keanggotaan
        $this->load->model('Menu_model', 'status_keanggotaan');
        $data['statusKeanggotaan'] = $this->status_keanggotaan->getStatusKeanggotaan($email);
        $data['status_keanggotaan'] = $this->db->get('keanggotaan')->result_array();

        //tanggal_update
        $this->load->model('Menu_model', 'tanggal_update');
        $data['tanggalUpdate'] = $this->tanggal_update->getTanggalUpdate($email);
        $data['tanggal_update'] = $this->db->get('user')->result_array();
        
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('user/index', $data);
        $this->load->view('templates/footer');
    }

    public function edit(){
        $data['title'] = 'Edit Profile';
        $data['user'] = $this->db->get_where('user', ['email' => 
        $this->session->userdata('email')])->row_array();

        $email= $this->session->userdata('email');
        
        // memanggil model jenis kelamin
        $this->load->model('Menu_model', 'jenis_kelamin');
        $data['jenisKelamin'] = $this->jenis_kelamin->getJenisKelamin($email);
        $data['jenis_kelamin'] = $this->db->get('jns_kelamin')->result_array();

        // memanggil model kewarganegaraan
        $this->load->model('Menu_model', 'kewarganegaraan');
        $data['kewargaNegaraan'] = $this->kewarganegaraan->getKewarganegaraan($email);
        $data['kewarganegaraan'] = $this->db->get('kenegaraan')->result_array();

        // dropdown kawasan/zona
        $this->load->model('Menu_model', 'kawasan');
        $data['zona'] = $this->kawasan->getKawasan($email);
        $data['kawasan'] = $this->db->get('zona')->result_array();

        // memanggil model keahlian
        $this->load->model('Menu_model', 'kluster_keahlian');
        $data['klusterKeahlian'] = $this->kluster_keahlian->getKlusterKeahlian($email);
        $data['kluster_keahlian'] = $this->db->get('keahlian')->result_array();

        // memanggil model keanggotaan
        $this->load->model('Menu_model', 'status_keanggotaan');
        $data['statusKeanggotaan'] = $this->status_keanggotaan->getStatusKeanggotaan($email);
        $data['status_keanggotaan'] = $this->db->get('keanggotaan')->result_array();

        //tanggal_update
        $this->load->model('Menu_model', 'tanggal_update');
        $data['tanggalUpdate'] = $this->tanggal_update->getTanggalUpdate($email);
        $data['tanggal_update'] = $this->db->get('user')->result_array();
        
        $this->form_validation->set_rules('nama', 'Nama', 'required|trim');
        
        if($this->form_validation->run() == false){
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('user/edit', $data);
            $this->load->view('templates/footer');
        }else{
            $nama = $this->input->post('nama');
            $jenis_kelamin_id = $this->input->post('jenis_kelamin_id');
            $kewarganegaraan_id = $this->input->post('kewarganegaraan_id');
            $kawasan_id = $this->input->post('kawasan_id');
            $negara = $this->input->post('negara');
            $kota = $this->input->post('kota');
            $gelar = $this->input->post('gelar');
            $institusi = $this->input->post('institusi');
            $departemen = $this->input->post('departemen');
            $jabatan = $this->input->post('jabatan');
            $kluster_keahlian_id = $this->input->post('kluster_keahlian_id');
            $email_resmi = $this->input->post('email_resmi');
            $email = $this->input->post('email');
            $no_telp = $this->input->post('no_telp');
            $website = $this->input->post('website');
            $research_interest = $this->input->post('research_interest');
            $research = $this->input->post('research');
            $status_keanggotaan_id = $this->input->post('status_keanggotaan_id');
            $tanggal_update = $this->input->post('tanggal_update');

            $this->db->set('nama', $nama);
            $this->db->set('jenis_kelamin_id', $jenis_kelamin_id);
            $this->db->set('kewarganegaraan_id', $kewarganegaraan_id);
            $this->db->set('kawasan_id', $kawasan_id);
            $this->db->set('negara', $negara);
            $this->db->set('kota', $kota);
            $this->db->set('gelar', $gelar);
            $this->db->set('institusi', $institusi);
            $this->db->set('departemen', $departemen);
            $this->db->set('jabatan', $jabatan);
            $this->db->set('kluster_keahlian_id', $kluster_keahlian_id);
            $this->db->set('email_resmi', $email_resmi);
            $this->db->set('no_telp', $no_telp);
            $this->db->set('website', $website);
            $this->db->set('research_interest', $research_interest);
            $this->db->set('research', $research);
            $this->db->set('status_keanggotaan_id', $status_keanggotaan_id);
            $this->db->set('tanggal_update', $tanggal_update);

            $this->db->where('email', $email);

            $this->db->update('user');
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Your Profile Has Been Changed</div>');
            redirect('user');
        }
    }
}