<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

    public function __construct(){
        parent::__construct();
        is_logged_in();
    }

    public function index(){
        $data['title'] = 'My Profile';
        $data['user'] = $this->db->get_where('user', ['email' => 
        $this->session->userdata('email')])->row_array();
        
        // dropdown jenis kelamin
        $this->load->model('Menu_model', 'jenis_kelamin');
        $data['jenisKelamin'] = $this->jenis_kelamin->getJenisKelamin();
        $data['jenis_kelamin'] = $this->db->get('jns_kelamin')->result_array();

        // dropdown kewarganegaraan
        $this->load->model('Menu_model', 'kewarganegaraan');
        $data['kewargaNegaraan'] = $this->jenis_kelamin->getKewarganegaraan();
        $data['kewarganegaraan'] = $this->db->get('kenegaraan')->result_array();

        // dropdown keahlian
        $this->load->model('Menu_model', 'kluster_keahlian');
        $data['klusterKeahlian'] = $this->kluster_keahlian->getKlusterKeahlian();
        $data['kluster_keahlian'] = $this->db->get('keahlian')->result_array();

        // dropdown keanggotaan
        $this->load->model('Menu_model', 'status_keanggotaan');
        $data['statusKeanggotaan'] = $this->status_keanggotaan->getStatusKeanggotaan();
        $data['status_keanggotaan'] = $this->db->get('keanggotaan')->result_array();
        
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('user/index', $data);
        $this->load->view('templates/footer');
    }

    public function edit(){
        $data['title'] = 'Edit Profile';
        $data['user'] = $this->db->get_where('user', ['email' => 
        $this->session->userdata('email')])->row_array();
        
        // memanggil model jenis kelamin
        $this->load->model('Menu_model', 'jenis_kelamin');
        $data['jenisKelamin'] = $this->jenis_kelamin->getJenisKelamin();
        $data['jenis_kelamin'] = $this->db->get('jns_kelamin')->result_array();

        // memanggil model kewarganegaraan
        $this->load->model('Menu_model', 'kewarganegaraan');
        $data['kewargaNegaraan'] = $this->jenis_kelamin->getKewarganegaraan();
        $data['kewarganegaraan'] = $this->db->get('kenegaraan')->result_array();

        // memanggil model keahlian
        $this->load->model('Menu_model', 'kluster_keahlian');
        $data['klusterKeahlian'] = $this->kluster_keahlian->getKlusterKeahlian();
        $data['kluster_keahlian'] = $this->db->get('keahlian')->result_array();

        // memanggil model keanggotaan
        $this->load->model('Menu_model', 'status_keanggotaan');
        $data['statusKeanggotaan'] = $this->status_keanggotaan->getStatusKeanggotaan();
        $data['status_keanggotaan'] = $this->db->get('keanggotaan')->result_array();
        
        $this->form_validation->set_rules('nama', 'Nama', 'required|trim');

        $this->form_validation->set_rules('negara', 'Negara', 'required');
        $this->form_validation->set_rules('kota', 'Kota', 'required');
        $this->form_validation->set_rules('gelar', 'Gelar', 'required');
        $this->form_validation->set_rules('institusi', 'Institusi', 'required');
        $this->form_validation->set_rules('departemen', 'Departemen', 'required');


        $this->form_validation->set_rules('email_resmi', 'Email_resmi', 'required');

        $this->form_validation->set_rules('no_telp', 'No_telp', 'required');
        $this->form_validation->set_rules('website', 'Website', 'required');
        $this->form_validation->set_rules('research_interest', 'Research_interest', 'required');
        $this->form_validation->set_rules('research', 'Research', 'required');


        
        if($this->form_validation->run() == false){
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('user/edit', $data);
            $this->load->view('templates/footer');
        }else{
            $nama = $this->input->post('nama');
            $jenis_kelamin_id = $this->input->post('jenis_kelamin_id');
            $kewarganegaraan_id = $this->input->post('kewarganegaraan_id');
            $negara = $this->input->post('negara');
            $kota = $this->input->post('kota');
            $gelar = $this->input->post('gelar');
            $institusi = $this->input->post('institusi');
            $departemen = $this->input->post('departemen');
            $jabatan = $this->input->post('jabatan');
            $kluster_keahlian_id = $this->input->post('kluster_keahlian_id');
            $email_resmi = $this->input->post('email_resmi');
            $email = $this->input->post('email');
            $no_telp = $this->input->post('no_telp');
            $website = $this->input->post('website');
            $research_interest = $this->input->post('research_interest');
            $research = $this->input->post('research');
            $status_keanggotaan_id = $this->input->post('status_keanggotaan_id');

            $this->db->set('nama', $nama);
            $this->db->set('jenis_kelamin_id', $jenis_kelamin_id);
            $this->db->set('kewarganegaraan_id', $kewarganegaraan_id);
            $this->db->set('negara', $negara);
            $this->db->set('kota', $kota);
            $this->db->set('gelar', $gelar);
            $this->db->set('institusi', $institusi);
            $this->db->set('departemen', $departemen);
            $this->db->set('kluster_keahlian_id', $kluster_keahlian_id);
            $this->db->set('email_resmi', $email_resmi);
            $this->db->set('no_telp', $no_telp);
            $this->db->set('website', $website);
            $this->db->set('research_interest', $research_interest);
            $this->db->set('research', $research);
            $this->db->set('status_keanggotaan_id', $status_keanggotaan_id);

            $this->db->where('email', $email);
            $this->db->where('jabatan', $jabatan);

            $this->db->update('user');
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Your Profile Has Been Changed</div>');
            redirect('user');
        }
    }
}