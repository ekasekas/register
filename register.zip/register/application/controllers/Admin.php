<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

    public function __construct(){
        parent::__construct();
        is_logged_in();
    }

    public function index(){
        $data['title'] = 'Dashboard';
        $data['user'] = $this->db->get_where('user', ['email' => 
        $this->session->userdata('email')])->row_array();

        $email= $this->session->userdata('email');

        //semua
        $this->load->model('Menu_model');
        $semua = $this->Menu_model->getAll(); // memanggil method getAll
        $data['semua'] = $semua; // menampung di variable $data

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/index', $data);
        $this->load->view('templates/footer');
    }

    public function role(){
        $data['title'] = 'Role';
        $data['user'] = $this->db->get_where('user', ['email' => 
        $this->session->userdata('email')])->row_array();
        
        $data['role'] = $this->db->get('user_role')->result_array();
        $this->form_validation->set_rules('role', 'Role', 'required');
        
        if($this->form_validation->run() == false ){
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/role', $data);
            $this->load->view('templates/footer');
        }else{
            $this->db->insert('user_role', ['role' => $this->input->post('role')]);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">New Role Added</div>');
            redirect('admin/role');
        }
        
    }

    public function editrole(){
        $data['title'] = 'Edit Role';
        $data['user'] = $this->db->get_where('user', ['email' => 
        $this->session->userdata('email')])->row_array();

        $data['role'] = $this->db->get('user_role')->result_array();

        $this->form_validation->set_rules('role', 'Role', 'required');
        
        if($this->form_validation->run() == false ){
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/editrole', $data);
            $this->load->view('templates/footer');
        }else{
            $id = $this->input->post('id');
            $role = $this->input->post('role');
            $this->db->set('role', $role);
            $this->db->where('id', $id);
            $this->db->update('user_role');
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Role has been changed</div>');
            redirect('admin/role');
        }
    }

    public function deleterole($id){
        $this->load->model('Menu_model');
        $this->Menu_model->deleteRole($id);

        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Role has been deleted</div>');
        redirect('admin/role');
    }

    public function roleAccess($role_id){
        $data['title'] = 'Role Access';
        $data['user'] = $this->db->get_where('user', ['email' => 
        $this->session->userdata('email')])->row_array();
        
        $data['role'] = $this->db->get_where('user_role', ['id' => $role_id])->row_array();

        //cara agar admin tidak ditampilkan
        $this->db->where('id !=' , 1);
        $data['menu'] = $this->db->get('user_menu')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/roleaccess', $data);
        $this->load->view('templates/footer');
    }

    public function changeAccess(){
        $menu_id = $this->input->post('menuId');
        $role_id = $this->input->post('roleId');

        $data = [
            'role_id' => $role_id,
            'menu_id' => $menu_id
        ];

        $result = $this->db->get_where('user_access_menu', $data);

        if($result->num_rows() < 1){
            $this->db->insert('user_access_menu', $data);
        }else{
            $this->db->delete('user_access_menu', $data);
        }

        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Your Access Has Been Changed</div>');

    }

    public function excel(){
        $data['user'] = $this->db->get_where('user', ['email' => 
        $this->session->userdata('email')])->row_array();

        $email= $this->session->userdata('email');

        //semua
        $this->load->model('Menu_model');
        $semua = $this->Menu_model->getAll(); // memanggil method getAll
        $data['semua'] = $semua; // menampung di variable $data

        require(APPPATH. 'PHPExcel-1.8/Classes/PHPExcel.php');
        require(APPPATH. 'PHPExcel-1.8/Classes/PHPExcel/Writer/Excel2007.php');

        $object = new PHPExcel();

        $object->getProperties()->setTitle("Data Anggota");

        $object->setActiveSheetIndex(0);

        $object->getActiveSheet()->setCellValue('A1', 'No');
        $object->getActiveSheet()->setCellValue('B1', 'Nama Anggota');
        $object->getActiveSheet()->setCellValue('C1', 'Email');
        $object->getActiveSheet()->setCellValue('D1', 'jenis Kelamin');
        $object->getActiveSheet()->setCellValue('E1', 'Kawasan');
        $object->getActiveSheet()->setCellValue('F1', 'Negara');
        $object->getActiveSheet()->setCellValue('G1', 'Kota');
        $object->getActiveSheet()->setCellValue('H1', 'Gelar');
        $object->getActiveSheet()->setCellValue('I1', 'Institusi');
        $object->getActiveSheet()->setCellValue('J1', 'Departemen');
        $object->getActiveSheet()->setCellValue('K1', 'Jabatan');
        $object->getActiveSheet()->setCellValue('L1', 'Kluster Keahlian');
        $object->getActiveSheet()->setCellValue('M1', 'Email Resmi');
        $object->getActiveSheet()->setCellValue('N1', 'No Telp');
        $object->getActiveSheet()->setCellValue('O1', 'Website');
        $object->getActiveSheet()->setCellValue('P1', 'Research Interest');
        $object->getActiveSheet()->setCellValue('Q1', 'Google Scholar / Scopus ID / RG / ORCHID / PUBLONS / LinkedIn');
        $object->getActiveSheet()->setCellValue('R1', 'Status Keanggotaan');
        $object->getActiveSheet()->setCellValue('S1', 'Tanggal Update');
    
        $baris = 2;
        $no = 1;
        
        foreach($semua->result() as $result){
            $object->getActiveSheet()->setCellValue('A'.$baris, $no++);
            $object->getActiveSheet()->setCellValue('B'.$baris, $result->nama);
            $object->getActiveSheet()->setCellValue('C'.$baris, $result->email);
            $object->getActiveSheet()->setCellValue('D'.$baris, $result->jenis_kelamin);
            $object->getActiveSheet()->setCellValue('E'.$baris, $result->kawasan);
            $object->getActiveSheet()->setCellValue('F'.$baris, $result->negara);
            $object->getActiveSheet()->setCellValue('G'.$baris, $result->kota);
            $object->getActiveSheet()->setCellValue('H'.$baris, $result->gelar);
            $object->getActiveSheet()->setCellValue('I'.$baris, $result->institusi);
            $object->getActiveSheet()->setCellValue('J'.$baris, $result->departemen);
            $object->getActiveSheet()->setCellValue('K'.$baris, $result->jabatan);
            $object->getActiveSheet()->setCellValue('L'.$baris, $result->kluster_keahlian);
            $object->getActiveSheet()->setCellValue('M'.$baris, $result->email_resmi);
            $object->getActiveSheet()->setCellValue('N'.$baris, $result->no_telp);
            $object->getActiveSheet()->setCellValue('O'.$baris, $result->website);
            $object->getActiveSheet()->setCellValue('P'.$baris, $result->research_interest);
            $object->getActiveSheet()->setCellValue('Q'.$baris, $result->research);
            $object->getActiveSheet()->setCellValue('R'.$baris, $result->status_keanggotaan);
            $object->getActiveSheet()->setCellValue('S'.$baris, $result->tanggal_update);
        
            $baris++;
        }

        $filename="data_anggota".'.xlsx';

        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="'.$filename. '"');
        header('Cache-Control: max-age=0');

        $writer=PHPExcel_IOFactory::createwriter($object, 'Excel2007');
        $writer->save('php://output');

        exit;
    }

}